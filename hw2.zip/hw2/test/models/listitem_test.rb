require "test_helper"

class ListitemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
