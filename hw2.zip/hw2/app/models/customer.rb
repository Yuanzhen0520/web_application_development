class Customer < ApplicationRecord
end
