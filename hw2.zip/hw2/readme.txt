/products to see the host view.
/shopper/list to see the customer view.
/access/login to see the login page. Username: remy, password: 12345
